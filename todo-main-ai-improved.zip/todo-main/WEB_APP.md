# Anchor web app

Open `index.html` in a browser, or serve the project directory with any static HTTP server. The browser app is a self-contained single-page experience; task changes are stored in local storage in that browser. The existing Android app source remains in `app/`.

## Four design passes

Each visible area went through the same four passes in the delivered implementation:

1. **Structure:** established the information order and the role of each section: persistent navigation, page context, daily overview, focused list, and supporting content.
2. **Visual rehab:** tuned spacing, typography, color, surfaces, contrast, and interaction affordances to create a quieter and more consistent visual system.
3. **Behavior:** connected navigation, capture, completion and restore, search, focus mode, empty states, in-place task actions, and undo to real browser behavior and local persistence.
4. **Resolution and access:** added layouts for wide desktop, 4K, tablet, and mobile widths; scalable vector interface elements; visible keyboard focus; labels for controls; and reduced-motion support.

This is an implementation log of the four refinement passes, not a claim that independent design reviewers or visual regression tests were run.

At 3840px, the interface expands its content canvas while keeping line lengths and section proportions controlled. All interface artwork is CSS or inline SVG, so it does not rely on low-resolution raster assets.
