const storageKey = 'anchor-web-items-v1';
const dayName = new Intl.DateTimeFormat('en', { weekday: 'long' }).format(new Date());
const shortDate = new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(new Date());
const dateLabel = new Intl.DateTimeFormat('en', { weekday: 'long', month: 'short', day: 'numeric' }).format(new Date()).toUpperCase();
const initialItems = [
  { id: 1, title: 'Review the first draft of the brand story', area: 'Studio North', time: '09:30 AM', category: 'today', tag: 'CREATIVE', tone: 'lime', priority: 'high', done: false },
  { id: 2, title: 'Send revised timeline to Olivia', area: 'Client work', time: '10:45 AM', category: 'today', tag: 'WORK', tone: 'blue', priority: '', done: false },
  { id: 3, title: 'Pick up a few things for dinner', area: 'Personal', time: '12:00 PM', category: 'today', tag: 'LIFE', tone: 'orange', priority: '', done: false },
  { id: 4, title: 'Block an hour for the proposal outline', area: 'Studio North', time: '02:30 PM', category: 'today', tag: 'CREATIVE', tone: 'lime', priority: '', done: false },
  { id: 5, title: 'Look into a better home for my photo archive', area: 'Captured just now', time: 'INBOX', category: 'inbox', tag: 'PERSONAL', tone: 'blue', priority: '', done: false },
  { id: 6, title: 'Ask Sam about the November workshop', area: 'Captured yesterday', time: 'INBOX', category: 'inbox', tag: 'PEOPLE', tone: 'orange', priority: '', done: false },
  { id: 7, title: 'Replace the hallway light', area: 'Captured Monday', time: 'INBOX', category: 'inbox', tag: 'HOME', tone: 'blue', priority: '', done: false },
  { id: 8, title: 'Prepare the November studio newsletter', area: 'Studio North', time: 'MON, NOV 3', category: 'upcoming', tag: 'CREATIVE', tone: 'lime', priority: 'high', done: false },
  { id: 9, title: 'Dentist appointment', area: 'Personal', time: 'WED, NOV 5', category: 'upcoming', tag: 'LIFE', tone: 'orange', priority: '', done: false },
  { id: 10, title: 'Confirm venue options for winter gathering', area: 'Personal', time: 'FRI, NOV 7', category: 'upcoming', tag: 'PEOPLE', tone: 'blue', priority: '', done: false },
  { id: 11, title: 'Send the final moodboard to the team', area: 'Studio North', time: '08:45 AM', category: 'done', tag: 'CREATIVE', tone: 'lime', priority: '', done: true },
  { id: 12, title: 'Book a table for Friday', area: 'Personal', time: 'YESTERDAY', category: 'done', tag: 'LIFE', tone: 'orange', priority: '', done: true },
  { id: 13, title: 'Weekend ideas', body: 'Slow breakfast. Take the long way to the farmers market. Get outside before the afternoon.', category: 'notes', tag: 'PERSONAL', tone: 'orange' },
  { id: 14, title: 'Things to ask at the kickoff', body: 'What does a great first month look like? Who gives final approval? What is already working well?', category: 'notes', tag: 'STUDIO NORTH', tone: 'lime' },
  { id: 15, title: 'A thought on the new direction', body: 'It should feel considered but never precious. Warm materials, a little imperfection, room to breathe.', category: 'notes', tag: 'IDEAS', tone: 'blue' }
];
let items;
try { items = JSON.parse(localStorage.getItem(storageKey)) || initialItems; } catch { items = initialItems; }
let activeView = 'today';
let query = '';
let toastTimer;
let undoAction = null;
const content = document.querySelector('#page-content');
const dialog = document.querySelector('#task-dialog');
const input = document.querySelector('#task-input');
const destination = document.querySelector('#task-destination');
const toastEl = document.querySelector('#toast');

document.querySelector('#date-chip').textContent = dateLabel;
function save() { localStorage.setItem(storageKey, JSON.stringify(items)); }
function showToast(message, undo = null) {
  undoAction = undo;
  toastEl.replaceChildren(document.createTextNode(message));
  if (undo) {
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'toast-undo'; button.textContent = 'Undo';
    button.addEventListener('click', () => { const restore = undoAction; undoAction = null; restore?.(); toastEl.classList.remove('show'); });
    toastEl.append(button);
  }
  toastEl.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => { toastEl.classList.remove('show'); undoAction = null; }, 4200);
}
function escapeHtml(value = '') { return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
function itemRows(category) {
  const list = items.filter(item => item.category === category && (category !== 'today' || !item.done) && (!query || `${item.title} ${item.area || ''} ${item.tag || ''}`.toLowerCase().includes(query.toLowerCase())));
  if (!list.length) return '<div class="empty-state"><b>Room to breathe.</b>Nothing here yet. Capture a thought and let Anchor hold it for you.</div>';
  return list.map(item => `<article class="task-row ${item.done ? 'completed' : ''}" data-id="${item.id}">
    ${category !== 'notes' ? `<button class="task-check" data-action="complete" aria-label="${item.done ? 'Restore' : 'Complete'} ${escapeHtml(item.title)}">${item.done ? '✓' : ''}</button>` : '<span class="task-check" aria-hidden="true" style="border-radius:4px"></span>'}
    <div class="task-main"><div class="task-title">${escapeHtml(item.title)}</div><div class="task-meta"><span>${escapeHtml(item.area || 'Personal')}</span><i class="meta-dot"></i><span class="tag ${item.tone || 'lime'}">${escapeHtml(item.tag || category.toUpperCase())}</span>${item.priority ? `<span class="priority ${item.priority}">◆ ${item.priority.toUpperCase()}</span>` : ''}</div></div>
    <div class="task-time">${escapeHtml(item.time || '')}</div><button class="task-more" data-action="more" aria-label="Actions for ${escapeHtml(item.title)}" aria-haspopup="menu" aria-expanded="false">···</button></article>`).join('');
}
function section(title, count, category, symbol = '◷') { return `<div class="section-head"><div class="section-title"><span class="section-mark">${symbol}</span>${title}<small>${String(count).padStart(2, '0')}</small></div><button class="section-action" data-add="${category}">+ Add task</button></div><div class="task-list">${itemRows(category)}</div>`; }
function header(kicker, title, subtitle, button = 'Add a task') { return `<div class="page-heading"><div><div class="heading-kicker"><span class="sun">✳</span>${kicker}</div><h1>${title}</h1><p class="heading-sub">${subtitle}</p></div><div class="heading-actions"><button class="subtle-button" data-action="focus">✳ &nbsp; Focus mode</button><button class="primary-button" data-add="${activeView}">＋ ${button}</button></div></div>`; }
function todayMarkup() {
  const today = items.filter(item => item.category === 'today' && !item.done);
  const completeCount = items.filter(item => item.category === 'today' && item.done).length;
  return `${header(`${dayName.toUpperCase()} · ${shortDate.toUpperCase()}`, `A little more <em>space.</em>`, 'A clear head starts with one thing at a time.')}
    <div class="overview-grid"><section class="focus-card"><div class="focus-eyebrow"><i></i> YOUR DAILY ANCHOR</div><h2 class="focus-title">Make progress, not pressure.</h2><p class="focus-copy">A steady pace is still a beautiful pace. You’ve got this.</p><div class="focus-footer"><div class="progress-track"><span style="width:${Math.min(100, (completeCount / Math.max(1, completeCount + today.length)) * 100)}%"></span></div><small>${completeCount} OF ${completeCount + today.length} COMPLETE</small><button data-action="focus">Enter focus mode ↗</button></div></section><section class="focus-stat"><div class="stat-top"><span>YOUR DAY, IN VIEW</span><span class="stat-spark">↗</span></div><div class="stat-number">${String(today.length).padStart(2, '0')} <span>things to tend to</span></div><div class="stat-bottom"><span class="trend">${completeCount ? `${completeCount} done` : 'One thing at a time'}</span><span>·</span><span>You’re right on time</span></div></section></div>
    ${section('Today', today.length, 'today')}
    <button class="quick-add" data-add="today"><span class="plus">＋</span><span>Add something to today</span><kbd>↵</kbd></button>
    <div class="lower-grid"><section><div class="section-head" style="margin-top:32px"><div class="section-title"><span class="section-mark">▦</span>The days ahead</div><button class="section-action" data-view="upcoming">See your week ↗</button></div><div class="week-strip">${weekCards()}</div><div class="page-note">A GOOD DAY IS BUILT ONE MOMENT AT A TIME.</div></section><aside class="ritual-card"><div class="ritual-top"><span>✦ A SMALL RITUAL</span><span>01 / 03</span></div><h3>Take a breath.</h3><p>Before the next thing, let this moment be enough. Your list will wait.</p><button class="ritual-button" data-action="ritual">Take 30 seconds ↗</button></aside></div>`;
}
function weekCards() {
  const days = Array.from({length: 5}, (_, i) => new Date(Date.now() + i * 86400000));
  return days.map((date, index) => { const count = index === 0 ? items.filter(i => i.category === 'today' && !i.done).length : items.filter(i => i.category === 'upcoming').length && index < 4 ? Math.min(3, index) : 0; return `<div class="day-card ${index === 0 ? 'today' : ''}"><div class="day-label"><span>${new Intl.DateTimeFormat('en', {weekday:'short'}).format(date)}</span><span>${String(count).padStart(2,'0')}</span></div><div class="day-date">${new Intl.DateTimeFormat('en', {month:'short',day:'numeric'}).format(date)}</div><div class="day-dots">${Array.from({length: count}, () => '<i></i>').join('')}</div></div>`; }).join('');
}
function render() {
  document.querySelectorAll('.nav-item[data-view]').forEach(button => { button.classList.toggle('active', button.dataset.view === activeView); });
  document.querySelector('#crumb-view').textContent = activeView.toUpperCase();
  const inboxCount = items.filter(item => item.category === 'inbox').length;
  const todayCount = items.filter(item => item.category === 'today' && !item.done).length;
  document.querySelector('#inbox-count').textContent = inboxCount;
  document.querySelector('#today-count').textContent = todayCount;
  document.querySelector('#upcoming-count').textContent = items.filter(item => item.category === 'upcoming').length;
  if (activeView === 'today') content.innerHTML = todayMarkup();
  else if (activeView === 'inbox') content.innerHTML = `${header('CAPTURED, NOT FORGOTTEN', 'Your <em>inbox.</em>', 'A soft landing for all the things you don’t want to lose.', 'Capture a thought')}${section('Ready when you are', items.filter(i => i.category === 'inbox').length, 'inbox', '⌑')}<div class="page-note">SORT IT WHEN YOU’RE READY. THERE’S NO RUSH.</div>`;
  else if (activeView === 'upcoming') content.innerHTML = `${header('A LITTLE LOOK AHEAD', 'Coming into <em>view.</em>', 'Make room for what’s next, without carrying it all today.', 'Plan ahead')}<div class="week-strip">${weekCards()}</div>${section('On the horizon', items.filter(i => i.category === 'upcoming').length, 'upcoming', '▦')}<div class="page-note">YOUR FUTURE SELF WILL THANK YOU FOR THE SPACE.</div>`;
  else if (activeView === 'notes') content.innerHTML = `${header('THOUGHTS, HELD GENTLY', 'A place for <em>ideas.</em>', 'Small sparks, useful details, and things worth keeping.', 'New note')}<div class="notes-grid">${items.filter(i => i.category === 'notes' && (!query || `${i.title} ${i.body}`.toLowerCase().includes(query.toLowerCase()))).map(item => `<article class="note-card"><span class="tag ${item.tone}">${escapeHtml(item.tag)}</span><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.body)}</p></article>`).join('') || '<div class="empty-state">No notes yet. Save a thought when it finds you.</div>'}</div><button class="quick-add" data-add="notes"><span class="plus">＋</span><span>Save a new thought</span><kbd>↵</kbd></button>`;
  else content.innerHTML = `${header('LOOK HOW FAR YOU’VE COME', 'Quietly <em>getting there.</em>', 'Every finished thing is a little promise you kept.', 'Add a task')}${section('Completed', items.filter(i => i.category === 'done').length, 'done', '✓')}<div class="page-note">SMALL STEPS COUNT. ESPECIALLY THE ONES NO ONE ELSE SEES.</div>`;
  if (query) content.querySelectorAll('.task-row').forEach(row => { if (!row.textContent.toLowerCase().includes(query.toLowerCase())) row.remove(); });
}
function openCapture(category = activeView) { destination.value = ['today', 'inbox', 'upcoming', 'notes'].includes(category) ? category : 'today'; dialog.showModal(); setTimeout(() => input.focus(), 60); }
function addItem() {
  const title = input.value.trim();
  if (!title) { input.focus(); return; }
  const category = destination.value;
  const tags = { today: 'TODAY', inbox: 'PERSONAL', upcoming: 'PLANNED', notes: 'NOTE' };
  items.unshift({ id: Date.now(), title, body: category === 'notes' ? 'A new thought, saved for later.' : undefined, area: 'Just captured', time: category === 'today' ? 'ANYTIME' : category === 'upcoming' ? 'NEXT UP' : category === 'notes' ? '' : 'INBOX', category, tag: tags[category], tone: 'lime', priority: '', done: false });
  save(); input.value = ''; dialog.close(); activeView = category; query = ''; render(); showToast(category === 'notes' ? 'Thought saved. Keep it close.' : 'Captured. It’s safe here.');
}
function complete(id) {
  const item = items.find(entry => entry.id === id);
  if (!item) return;
  const previous = { ...item };
  if (item.done) { item.done = false; item.category = 'today'; }
  else { item.done = true; item.category = 'done'; }
  save(); render();
  showToast(previous.done ? 'Back on your list.' : 'One thing lighter. Nicely done.', () => { Object.assign(item, previous); save(); render(); });
}
function moveOrDelete(id, target) {
  const item = items.find(entry => entry.id === id); if (!item) return;
  const previous = { ...item };
  if (target === 'delete') items = items.filter(entry => entry.id !== id);
  else { item.category = target; item.done = target === 'done'; }
  save(); render();
  showToast(target === 'delete' ? 'Removed from your list.' : target === 'today' ? 'Added to today.' : `Moved to ${target}.`, () => {
    if (target === 'delete') items.unshift(previous);
    else Object.assign(item, previous);
    save(); render();
  });
}
function openTaskMenu(button) {
  document.querySelectorAll('.task-menu').forEach(menu => menu.remove());
  document.querySelectorAll('.task-more[aria-expanded="true"]').forEach(open => open.setAttribute('aria-expanded', 'false'));
  const row = button.closest('[data-id]');
  const menu = document.createElement('div');
  menu.className = 'task-menu'; menu.setAttribute('role', 'menu');
  menu.innerHTML = '<span class="menu-label">MOVE TO</span><button role="menuitem" data-menu-target="today">Today</button><button role="menuitem" data-menu-target="inbox">Inbox</button><button role="menuitem" data-menu-target="upcoming">Upcoming</button><button role="menuitem" data-menu-target="done">Completed</button><span class="menu-divider"></span><button role="menuitem" class="delete-action" data-menu-target="delete">Delete task</button>';
  row.append(menu); button.setAttribute('aria-expanded', 'true'); menu.querySelector('button')?.focus();
}
document.querySelector('#navigation').addEventListener('click', event => { const button = event.target.closest('[data-view]'); if (button) { activeView = button.dataset.view; query = ''; render(); } });
content.addEventListener('click', event => {
  const add = event.target.closest('[data-add]'); if (add) { openCapture(add.dataset.add); return; }
  const view = event.target.closest('[data-view]'); if (view) { activeView = view.dataset.view; render(); return; }
  const action = event.target.closest('[data-action]'); if (!action) return;
  if (action.dataset.action === 'complete') complete(Number(action.closest('[data-id]').dataset.id));
  if (action.dataset.action === 'more') { openTaskMenu(action); return; }
  if (action.dataset.action === 'focus') toggleFocus();
  if (action.dataset.action === 'ritual') showToast('Breathe in. Breathe out. You’re here.');
});
content.addEventListener('click', event => {
  const option = event.target.closest('[data-menu-target]');
  if (option) {
    const row = option.closest('[data-id]');
    moveOrDelete(Number(row.dataset.id), option.dataset.menuTarget);
  } else if (!event.target.closest('.task-menu') && !event.target.closest('[data-action="more"]')) {
    document.querySelectorAll('.task-menu').forEach(menu => menu.remove());
    document.querySelectorAll('.task-more[aria-expanded="true"]').forEach(button => button.setAttribute('aria-expanded', 'false'));
  }
});
document.addEventListener('pointerdown', event => {
  if (event.target.closest('.task-menu, .task-more')) return;
  document.querySelectorAll('.task-menu').forEach(menu => menu.remove());
  document.querySelectorAll('.task-more[aria-expanded="true"]').forEach(button => button.setAttribute('aria-expanded', 'false'));
});
document.querySelector('#task-form').addEventListener('submit', event => { event.preventDefault(); addItem(); });
document.querySelector('#search-toggle').addEventListener('click', event => {
  const existing = document.querySelector('.search-box');
  if (existing) { query = ''; existing.remove(); render(); return; }
  const search = document.createElement('input'); search.className = 'search-box'; search.placeholder = 'Find a task…'; search.setAttribute('aria-label', 'Search tasks'); event.currentTarget.before(search); search.focus();
  search.addEventListener('input', () => { query = search.value; render(); const replacement = document.querySelector('.search-box'); if (replacement) { replacement.value = query; replacement.focus(); replacement.setSelectionRange(query.length, query.length); } });
  search.addEventListener('keydown', e => { if (e.key === 'Escape') { query = ''; search.remove(); render(); } });
});
function toggleFocus() { document.body.classList.toggle('focus-mode'); showToast(document.body.classList.contains('focus-mode') ? 'Focus mode is on. One thing at a time.' : 'Focus mode is off.'); }
document.querySelector('#focus-button').addEventListener('click', toggleFocus);
document.querySelector('#settings-button').addEventListener('click', () => showToast('Your space is set up just for you.'));
document.querySelector('#profile-button').addEventListener('click', () => showToast('Hello, Alex. You’re right where you need to be.'));
document.addEventListener('keydown', event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); openCapture('today'); }
  if (event.key === 'Escape' && dialog.open) dialog.close();
  if (event.key === 'Escape') { document.querySelectorAll('.task-menu').forEach(menu => menu.remove()); document.querySelectorAll('.task-more[aria-expanded="true"]').forEach(button => { button.setAttribute('aria-expanded', 'false'); button.focus(); }); }
  if (event.key === 'ArrowDown' && event.target.matches('.task-menu [role="menuitem"]')) { event.preventDefault(); const buttons = [...event.target.parentElement.querySelectorAll('[role="menuitem"]')]; buttons[(buttons.indexOf(event.target) + 1) % buttons.length].focus(); }
  if (event.key === 'ArrowUp' && event.target.matches('.task-menu [role="menuitem"]')) { event.preventDefault(); const buttons = [...event.target.parentElement.querySelectorAll('[role="menuitem"]')]; buttons[(buttons.indexOf(event.target) - 1 + buttons.length) % buttons.length].focus(); }
});
render();
